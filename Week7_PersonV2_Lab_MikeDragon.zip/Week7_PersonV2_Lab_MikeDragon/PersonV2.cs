﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace Week6_Lab6_MikeDragon
{
    //Inheriting data from the parent class: Person()
    class PersonV2: Person
    {
        private string cell;
        private string insta;

        //Start of public Get/Sets

        //Needs validation: (Length - 12)
        public string Cell
        {
            get
            {
                return cell;
            }

            set
            {
                if (ValidationLibrary.MinAmount(value, 12) == true)
                {
                    cell = value;
                }

                else
                {
                    Feedback = ($"ERROR: The entry for [Cell Phone] was not properly formatted. Use only 10 numbers and (-). (Ex: 860-208-0101)");
                }
            }
        }

        //Needs validation: Checks for 'instagram.com/' | Error if not contained
        public string Insta
        {
            get
            {
                return insta;
            }

            set
            {
                if (ValidationLibrary.InstaCheck(value) == true)
                {
                    insta = value;
                }

                else
                {
                    Feedback = ($"ERROR: The entry for [Instagram] was not properly formatted. (Ex: instagram.com/...)");
                }
            }
        }

        //Connects to the SQL Server
        public string AddARecord()
        {
            string result = "";

            SqlConnection Connect = new SqlConnection();

            Connect.ConnectionString = @"Server=sql.neit.edu\studentsqlserver,4500;Database=SE245_MDragon;User Id=SE245_MDragon;Password=000859945;";

            //Adding of the Record:
            string strSQL = "INSERT INTO PersonV2 (FirstName, MiddleName, LastName, Street1, Street2, City, State, Zip, Phone, Cell, Email, Insta) VALUES (@FirstName, @MiddleName, @LastName, @Street1, @Street2, @City, @State, @Zip, @Phone, @Cell, @Email, @Insta)";

            SqlCommand comm = new SqlCommand();
            comm.CommandText = strSQL;
            comm.Connection = Connect;

            //Entering the data from the form fields
            comm.Parameters.AddWithValue("@FirstName", FirstName);
            comm.Parameters.AddWithValue("@MiddleName", MiddleName);
            comm.Parameters.AddWithValue("@LastName", LastName);
            comm.Parameters.AddWithValue("@Street1", Street1);
            comm.Parameters.AddWithValue("@Street2", Street2);
            comm.Parameters.AddWithValue("@City", City);
            comm.Parameters.AddWithValue("@State", State);
            comm.Parameters.AddWithValue("@Zip", Zip);
            comm.Parameters.AddWithValue("@Phone", Phone);
            comm.Parameters.AddWithValue("@Cell", Cell);
            comm.Parameters.AddWithValue("@Email", Email);
            comm.Parameters.AddWithValue("@Insta", Insta);

            try
            {
                Connect.Open();
                int RecordsAdded = comm.ExecuteNonQuery();
                result = $"Added {RecordsAdded} record(s) successfully.";
                Connect.Close();
            }

            catch (Exception error)
            {
                result = "ERROR: " + error.Message;
            }

            finally
            {

            }

            return result;
        }

        //Constructor for PersonV2() class
        public PersonV2(): base()
        {
            cell = "";
            insta = "";
        }
    }
}
