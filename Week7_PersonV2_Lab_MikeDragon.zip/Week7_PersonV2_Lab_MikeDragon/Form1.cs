﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Week6_Lab6_MikeDragon
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //TESTING: Auto-fills the form
        private void btnTestFill_Click(object sender, EventArgs e)
        {
            txbxFirstName.Text = "Michael";
            txbxMiddleName.Text = "Anthony";
            txbxLastName.Text = "Dragon";
            txbxStreet1.Text = "114 Breakneck Hill Road";
            txbxStreet2.Text = "N/A";
            txbxCity.Text = "Dayville";
            txbxState.Text = "CT";
            txbxZip.Text = "06241";
            txbxPhone.Text = "860-208-9393";
            txbxEmail.Text = "madragon@email.neit.edu";
            txbxCell.Text = "860-617-6400";
            txbxInsta.Text = "instagram.com/MavereX";
        }

        //TESTING: Clears the form
        private void btnClear_Click(object sender, EventArgs e)
        {
            txbxFirstName.Text = "";
            txbxMiddleName.Text = "";
            txbxLastName.Text = "";
            txbxStreet1.Text = "";
            txbxStreet2.Text = "";
            txbxCity.Text = "";
            txbxState.Text = "";
            txbxZip.Text = "";
            txbxPhone.Text = "";
            txbxEmail.Text = "";
            txbxCell.Text = "";
            txbxInsta.Text = "";

            lblFeedback.Text = "...";
        }

        //Submits the data when there are no more errors!
        private void btnSubmit_Click(object sender, EventArgs e)
        {
            PersonV2 temp = new PersonV2();

            temp.FirstName = txbxFirstName.Text;
            temp.MiddleName = txbxMiddleName.Text;
            temp.LastName = txbxLastName.Text;
            temp.Street1 = txbxStreet1.Text;
            temp.Street2 = txbxStreet2.Text;
            temp.City = txbxCity.Text;
            temp.State = txbxState.Text;
            temp.Zip = txbxZip.Text;
            temp.Phone = txbxPhone.Text;
            temp.Email = txbxEmail.Text;
            temp.Cell = txbxCell.Text;
            temp.Insta = txbxInsta.Text;

            //Feedback Output
            if (temp.Feedback.Contains("ERROR:"))
            {
                lblFeedback.Text = temp.Feedback;
            }

            else
            {
                lblFeedback.Text = temp.AddARecord();
            }
        }
    }
}
