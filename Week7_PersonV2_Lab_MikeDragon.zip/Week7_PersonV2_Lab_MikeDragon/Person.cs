﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week6_Lab6_MikeDragon
{
    public class Person
    {
        private string firstName;
        private string middleName;
        private string lastName;
        private string street1;
        private string street2;
        private string city;
        private string state;
        private string zip;
        private string phone;
        private string email;
        private string feedback;

        //Start of public Get/Sets!

        //Needs validation: Can't be blank
        public string FirstName
        {
            get
            {
                return firstName;
            }

            set
            {
                if (ValidationLibrary.FilledIn(value) == true)
                {
                    firstName = value;
                }

                else
                {
                    Feedback = ($"ERROR: [First Name] is a mandatory field!");
                }
            }
        }

        //Street2 & Middle Name can be blank as not everyone has one
        public string MiddleName
        {
            get
            {
                return middleName;
            }

            set
            {
                middleName = value;
            }
        }

        //Needs validation: Can't be blank
        public string LastName
        {
            get
            {
                return lastName;
            }

            set
            {
                if (ValidationLibrary.FilledIn(value) == true)
                {
                    lastName = value;
                }

                else
                {
                    Feedback = ($"ERROR: [Last Name] is a mandatory field!");
                }
            }
        }

        //Needs validation: Can't be blank
        public string Street1
        {
            get
            {
                return street1;
            }

            set
            {
                if (ValidationLibrary.FilledIn(value) == true)
                {
                    street1 = value;
                }

                else
                {
                    Feedback = ($"ERROR: [Street 1] is a mandatory field!");
                }
            }
        }

        //Street2 & Middle Name can be blank as not everyone has one
        public string Street2
        {
            get
            {
                return street2;
            }

            set
            {
                street2 = value;
            }
        }

        //Needs validation: Can't be blank
        public string City
        {
            get
            {
                return city;
            }

            set
            {
                if (ValidationLibrary.FilledIn(value) == true)
                {
                    city = value;
                }

                else
                {
                    Feedback = ($"ERROR: [City] is a mandatory field!");
                }
            }
        }

        //Needs validation: (Length - 2)
        public string State
        {
            get
            {
                return state;
            }

            set
            {
                if (ValidationLibrary.MinAmount(value, 2) == true && ValidationLibrary.IsAllLetters(value) == true)
                {
                    state = value;
                }

                else
                {
                    Feedback = ($"ERROR: The entry for [State] was not formatted properly. Use only 2 letters. (Ex: CT)");
                }
            }
        }

        //Needs validation: (Length - 5)
        public string Zip
        {
            get
            {
                return zip;
            }

            set
            {
                if (ValidationLibrary.MinAmount(value, 5) == true && ValidationLibrary.IsAllNumbers(value) == true)
                {
                    zip = value;
                }

                else
                {
                    Feedback = ($"ERROR: The entry for [Zipcode] was not properly formatted. Use only 5 numbers. (Ex: 06260)");
                }
            }
        }

        //Needs validation: (Length - 12 | Excluding '-')
        public string Phone
        {
            get
            {
                return phone;
            }

            set
            {
                if (ValidationLibrary.MinAmount(value, 12) == true && ValidationLibrary.IsAllNumbers(value) == true)
                {
                    phone = value;
                }

                else
                {
                    Feedback = ($"ERROR: The entry for [Home Phone] was not properly formatted. Use only 10 numbers and (-). (Ex: 860-208-0101)");
                }
            }
        }

        //Needs validation
        public string Email
        {
            get
            {
                return email;
            }

            set
            {
                if (ValidationLibrary.IsValidEmail(value))
                {
                    email = value;
                }

                else
                {
                    Feedback = ($"ERROR: The entry for [Email] was not properly formatted. (Ex: abc@outlook.com)");
                }
            }
        }

        public string Feedback
        {
            get
            {
                return feedback;
            }

            set
            {
                feedback = value;
            }
        }

        //Constructor for Person() class
        public Person()
        {
            firstName = "";
            middleName = "";
            lastName = "";
            street1 = "";
            street2 = "";
            city = "";
            state = "";
            zip = "";
            phone = "";
            email = "";
            feedback = "";
    }
    }
}
