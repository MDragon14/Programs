﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week6_Lab6_MikeDragon
{
    class ValidationLibrary
    {
        //Checking for minimum amounts in the field =======================================||
        public static bool MinAmount(string temp, int min)
        {
            bool result;

            if (temp.Length < min)
            {
                result = false;
            }

            else
            {
                result = true;
            }

            return result;
        }

        //Checking to ensure data was entered =============================================||
        public static bool FilledIn(string temp)
        {
            bool result = false;

            if (temp.Length > 0)
            {
                result = true;
            }

            return result;
        }

        //Is all numbers =============================================================||
        public static bool IsAllNumbers(string temp)
        {
            bool result = false;

            string Numbers = "0123456789";

            foreach (char c in temp)
            {
                if (!Numbers.Contains(c))
                {
                    result = false;
                }

                else
                {
                    result = true;
                }
            }

            return result;
        }


        //Is all letters =============================================================||
        public static bool IsAllLetters(string temp)
        {
            bool result = false;

            string Letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

            foreach (char c in temp)
            {
                if (!Letters.Contains(c))
                {
                    result = false;
                }

                else
                {
                    result = true;
                }
            }

            return result;
        }


        //Checking for valid email formatting ========================================||
        public static bool IsValidEmail(string temp)
        {
            bool result = false;

            //Looks for position of "@"
            int AtLocation = temp.IndexOf("@");
            int NextAtLocation = AtLocation + 1;

            //Looks for position of final "."
            int PeriodLocation = temp.LastIndexOf(".");

            if (temp.Length < 8)
            {
                result = false;
            }

            else if (AtLocation < 2)
            {
                result = false;
            }

            else if (PeriodLocation + 2 > (temp.Length))
            {
                result = false;
            }

            else if (temp.LastIndexOf(".") >= NextAtLocation)
            {
                result = true;
            }

            return result;
        }

        //Checks for 'instagram.com/' in a string (FIXED per FB!)
        public static bool InstaCheck(string temp)
        {
            bool result;

            if (temp.Contains("instagram.com/") && (temp.Length >= 15))
            {
                result = true;
            }

            else
            {
                result = false;
            }

            return result;
        }
    }
}

