﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Week6_Lab6_MikeDragon
{
    class BasicTools
    {
        public static void Pause()
        {
            Console.WriteLine("\n\n\nPress Any Key to Exit... ");
            Console.ReadKey();
        }
    }
}
