﻿
namespace Week6_Lab6_MikeDragon
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblFirstName = new System.Windows.Forms.Label();
            this.lblMiddleName = new System.Windows.Forms.Label();
            this.lblLastName = new System.Windows.Forms.Label();
            this.lblStreet1 = new System.Windows.Forms.Label();
            this.lblStreet2 = new System.Windows.Forms.Label();
            this.lblCity = new System.Windows.Forms.Label();
            this.lblState = new System.Windows.Forms.Label();
            this.lblZip = new System.Windows.Forms.Label();
            this.lblPhone = new System.Windows.Forms.Label();
            this.lblEmail = new System.Windows.Forms.Label();
            this.lblFeedback = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txbxFirstName = new System.Windows.Forms.TextBox();
            this.txbxMiddleName = new System.Windows.Forms.TextBox();
            this.txbxLastName = new System.Windows.Forms.TextBox();
            this.txbxStreet1 = new System.Windows.Forms.TextBox();
            this.txbxStreet2 = new System.Windows.Forms.TextBox();
            this.txbxCity = new System.Windows.Forms.TextBox();
            this.txbxState = new System.Windows.Forms.TextBox();
            this.txbxZip = new System.Windows.Forms.TextBox();
            this.txbxPhone = new System.Windows.Forms.TextBox();
            this.txbxEmail = new System.Windows.Forms.TextBox();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.btnTestFill = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.lblCell = new System.Windows.Forms.Label();
            this.lblInsta = new System.Windows.Forms.Label();
            this.txbxCell = new System.Windows.Forms.TextBox();
            this.txbxInsta = new System.Windows.Forms.TextBox();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblPersonV2_ID = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblFirstName
            // 
            this.lblFirstName.AutoSize = true;
            this.lblFirstName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFirstName.Location = new System.Drawing.Point(9, 83);
            this.lblFirstName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblFirstName.Name = "lblFirstName";
            this.lblFirstName.Size = new System.Drawing.Size(101, 20);
            this.lblFirstName.TabIndex = 0;
            this.lblFirstName.Text = "First Name:";
            // 
            // lblMiddleName
            // 
            this.lblMiddleName.AutoSize = true;
            this.lblMiddleName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMiddleName.Location = new System.Drawing.Point(290, 83);
            this.lblMiddleName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMiddleName.Name = "lblMiddleName";
            this.lblMiddleName.Size = new System.Drawing.Size(117, 20);
            this.lblMiddleName.TabIndex = 1;
            this.lblMiddleName.Text = "Middle Name:";
            // 
            // lblLastName
            // 
            this.lblLastName.AutoSize = true;
            this.lblLastName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLastName.Location = new System.Drawing.Point(579, 83);
            this.lblLastName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(100, 20);
            this.lblLastName.TabIndex = 2;
            this.lblLastName.Text = "Last Name:";
            // 
            // lblStreet1
            // 
            this.lblStreet1.AutoSize = true;
            this.lblStreet1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStreet1.Location = new System.Drawing.Point(9, 166);
            this.lblStreet1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblStreet1.Name = "lblStreet1";
            this.lblStreet1.Size = new System.Drawing.Size(79, 20);
            this.lblStreet1.TabIndex = 3;
            this.lblStreet1.Text = "Street 1:";
            // 
            // lblStreet2
            // 
            this.lblStreet2.AutoSize = true;
            this.lblStreet2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStreet2.Location = new System.Drawing.Point(291, 166);
            this.lblStreet2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblStreet2.Name = "lblStreet2";
            this.lblStreet2.Size = new System.Drawing.Size(79, 20);
            this.lblStreet2.TabIndex = 4;
            this.lblStreet2.Text = "Street 2:";
            // 
            // lblCity
            // 
            this.lblCity.AutoSize = true;
            this.lblCity.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCity.Location = new System.Drawing.Point(9, 249);
            this.lblCity.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCity.Name = "lblCity";
            this.lblCity.Size = new System.Drawing.Size(44, 20);
            this.lblCity.TabIndex = 5;
            this.lblCity.Text = "City:";
            // 
            // lblState
            // 
            this.lblState.AutoSize = true;
            this.lblState.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblState.Location = new System.Drawing.Point(290, 249);
            this.lblState.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblState.Name = "lblState";
            this.lblState.Size = new System.Drawing.Size(63, 20);
            this.lblState.TabIndex = 6;
            this.lblState.Text = "State: ";
            // 
            // lblZip
            // 
            this.lblZip.AutoSize = true;
            this.lblZip.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblZip.Location = new System.Drawing.Point(399, 249);
            this.lblZip.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblZip.Name = "lblZip";
            this.lblZip.Size = new System.Drawing.Size(78, 20);
            this.lblZip.TabIndex = 7;
            this.lblZip.Text = "Zipcode:";
            // 
            // lblPhone
            // 
            this.lblPhone.AutoSize = true;
            this.lblPhone.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPhone.Location = new System.Drawing.Point(9, 334);
            this.lblPhone.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPhone.Name = "lblPhone";
            this.lblPhone.Size = new System.Drawing.Size(117, 20);
            this.lblPhone.TabIndex = 8;
            this.lblPhone.Text = "Home Phone:";
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmail.Location = new System.Drawing.Point(290, 334);
            this.lblEmail.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(58, 20);
            this.lblEmail.TabIndex = 9;
            this.lblEmail.Text = "Email:";
            // 
            // lblFeedback
            // 
            this.lblFeedback.AutoSize = true;
            this.lblFeedback.Location = new System.Drawing.Point(9, 528);
            this.lblFeedback.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblFeedback.Name = "lblFeedback";
            this.lblFeedback.Size = new System.Drawing.Size(21, 20);
            this.lblFeedback.TabIndex = 10;
            this.lblFeedback.Text = "...";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 32F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(3, 9);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(238, 51);
            this.label12.TabIndex = 11;
            this.label12.Text = "GrayPages";
            // 
            // txbxFirstName
            // 
            this.txbxFirstName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbxFirstName.Location = new System.Drawing.Point(13, 108);
            this.txbxFirstName.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txbxFirstName.Name = "txbxFirstName";
            this.txbxFirstName.Size = new System.Drawing.Size(206, 26);
            this.txbxFirstName.TabIndex = 12;
            // 
            // txbxMiddleName
            // 
            this.txbxMiddleName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbxMiddleName.Location = new System.Drawing.Point(294, 108);
            this.txbxMiddleName.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txbxMiddleName.Name = "txbxMiddleName";
            this.txbxMiddleName.Size = new System.Drawing.Size(206, 26);
            this.txbxMiddleName.TabIndex = 13;
            // 
            // txbxLastName
            // 
            this.txbxLastName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbxLastName.Location = new System.Drawing.Point(583, 108);
            this.txbxLastName.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txbxLastName.Name = "txbxLastName";
            this.txbxLastName.Size = new System.Drawing.Size(206, 26);
            this.txbxLastName.TabIndex = 14;
            // 
            // txbxStreet1
            // 
            this.txbxStreet1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbxStreet1.Location = new System.Drawing.Point(13, 191);
            this.txbxStreet1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txbxStreet1.Name = "txbxStreet1";
            this.txbxStreet1.Size = new System.Drawing.Size(206, 26);
            this.txbxStreet1.TabIndex = 15;
            // 
            // txbxStreet2
            // 
            this.txbxStreet2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbxStreet2.Location = new System.Drawing.Point(295, 191);
            this.txbxStreet2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txbxStreet2.Name = "txbxStreet2";
            this.txbxStreet2.Size = new System.Drawing.Size(206, 26);
            this.txbxStreet2.TabIndex = 16;
            // 
            // txbxCity
            // 
            this.txbxCity.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbxCity.Location = new System.Drawing.Point(13, 274);
            this.txbxCity.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txbxCity.Name = "txbxCity";
            this.txbxCity.Size = new System.Drawing.Size(206, 26);
            this.txbxCity.TabIndex = 17;
            // 
            // txbxState
            // 
            this.txbxState.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbxState.Location = new System.Drawing.Point(294, 274);
            this.txbxState.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txbxState.MaxLength = 2;
            this.txbxState.Name = "txbxState";
            this.txbxState.Size = new System.Drawing.Size(59, 26);
            this.txbxState.TabIndex = 18;
            // 
            // txbxZip
            // 
            this.txbxZip.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbxZip.Location = new System.Drawing.Point(403, 274);
            this.txbxZip.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txbxZip.MaxLength = 5;
            this.txbxZip.Name = "txbxZip";
            this.txbxZip.Size = new System.Drawing.Size(98, 26);
            this.txbxZip.TabIndex = 19;
            // 
            // txbxPhone
            // 
            this.txbxPhone.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbxPhone.Location = new System.Drawing.Point(13, 359);
            this.txbxPhone.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txbxPhone.Name = "txbxPhone";
            this.txbxPhone.Size = new System.Drawing.Size(206, 26);
            this.txbxPhone.TabIndex = 20;
            // 
            // txbxEmail
            // 
            this.txbxEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbxEmail.Location = new System.Drawing.Point(294, 359);
            this.txbxEmail.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txbxEmail.Name = "txbxEmail";
            this.txbxEmail.Size = new System.Drawing.Size(324, 26);
            this.txbxEmail.TabIndex = 21;
            // 
            // btnSubmit
            // 
            this.btnSubmit.FlatAppearance.BorderSize = 3;
            this.btnSubmit.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubmit.Location = new System.Drawing.Point(740, 436);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(111, 35);
            this.btnSubmit.TabIndex = 22;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // btnTestFill
            // 
            this.btnTestFill.BackColor = System.Drawing.Color.DarkRed;
            this.btnTestFill.FlatAppearance.BorderSize = 3;
            this.btnTestFill.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTestFill.ForeColor = System.Drawing.Color.Snow;
            this.btnTestFill.Location = new System.Drawing.Point(875, 9);
            this.btnTestFill.Name = "btnTestFill";
            this.btnTestFill.Size = new System.Drawing.Size(148, 42);
            this.btnTestFill.TabIndex = 23;
            this.btnTestFill.Text = "TEST DATA";
            this.btnTestFill.UseVisualStyleBackColor = false;
            this.btnTestFill.Click += new System.EventHandler(this.btnTestFill_Click);
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.Color.Teal;
            this.btnClear.FlatAppearance.BorderSize = 3;
            this.btnClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.ForeColor = System.Drawing.Color.Snow;
            this.btnClear.Location = new System.Drawing.Point(875, 57);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(148, 25);
            this.btnClear.TabIndex = 24;
            this.btnClear.Text = "CLEAR FORM";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // lblCell
            // 
            this.lblCell.AutoSize = true;
            this.lblCell.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCell.Location = new System.Drawing.Point(13, 420);
            this.lblCell.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCell.Name = "lblCell";
            this.lblCell.Size = new System.Drawing.Size(100, 20);
            this.lblCell.TabIndex = 26;
            this.lblCell.Text = "Cell Phone:";
            // 
            // lblInsta
            // 
            this.lblInsta.AutoSize = true;
            this.lblInsta.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInsta.Location = new System.Drawing.Point(290, 420);
            this.lblInsta.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblInsta.Name = "lblInsta";
            this.lblInsta.Size = new System.Drawing.Size(136, 20);
            this.lblInsta.TabIndex = 27;
            this.lblInsta.Text = "Instagram URL:";
            // 
            // txbxCell
            // 
            this.txbxCell.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbxCell.Location = new System.Drawing.Point(12, 445);
            this.txbxCell.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txbxCell.Name = "txbxCell";
            this.txbxCell.Size = new System.Drawing.Size(206, 26);
            this.txbxCell.TabIndex = 28;
            // 
            // txbxInsta
            // 
            this.txbxInsta.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbxInsta.Location = new System.Drawing.Point(295, 445);
            this.txbxInsta.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txbxInsta.Name = "txbxInsta";
            this.txbxInsta.Size = new System.Drawing.Size(323, 26);
            this.txbxInsta.TabIndex = 29;
            // 
            // btnExit
            // 
            this.btnExit.FlatAppearance.BorderSize = 3;
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(912, 436);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(111, 35);
            this.btnExit.TabIndex = 30;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lblPersonV2_ID
            // 
            this.lblPersonV2_ID.AutoSize = true;
            this.lblPersonV2_ID.Location = new System.Drawing.Point(390, 34);
            this.lblPersonV2_ID.Name = "lblPersonV2_ID";
            this.lblPersonV2_ID.Size = new System.Drawing.Size(0, 20);
            this.lblPersonV2_ID.TabIndex = 31;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(291, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(93, 20);
            this.label1.TabIndex = 32;
            this.label1.Text = "Person ID#:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1035, 722);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblPersonV2_ID);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.txbxInsta);
            this.Controls.Add(this.txbxCell);
            this.Controls.Add(this.lblInsta);
            this.Controls.Add(this.lblCell);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnTestFill);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.txbxEmail);
            this.Controls.Add(this.txbxPhone);
            this.Controls.Add(this.txbxZip);
            this.Controls.Add(this.txbxState);
            this.Controls.Add(this.txbxCity);
            this.Controls.Add(this.txbxStreet2);
            this.Controls.Add(this.txbxStreet1);
            this.Controls.Add(this.txbxLastName);
            this.Controls.Add(this.txbxMiddleName);
            this.Controls.Add(this.txbxFirstName);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.lblFeedback);
            this.Controls.Add(this.lblEmail);
            this.Controls.Add(this.lblPhone);
            this.Controls.Add(this.lblZip);
            this.Controls.Add(this.lblState);
            this.Controls.Add(this.lblCity);
            this.Controls.Add(this.lblStreet2);
            this.Controls.Add(this.lblStreet1);
            this.Controls.Add(this.lblLastName);
            this.Controls.Add(this.lblMiddleName);
            this.Controls.Add(this.lblFirstName);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblFirstName;
        private System.Windows.Forms.Label lblMiddleName;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.Label lblStreet1;
        private System.Windows.Forms.Label lblStreet2;
        private System.Windows.Forms.Label lblCity;
        private System.Windows.Forms.Label lblState;
        private System.Windows.Forms.Label lblZip;
        private System.Windows.Forms.Label lblPhone;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Label lblFeedback;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txbxFirstName;
        private System.Windows.Forms.TextBox txbxMiddleName;
        private System.Windows.Forms.TextBox txbxLastName;
        private System.Windows.Forms.TextBox txbxStreet1;
        private System.Windows.Forms.TextBox txbxStreet2;
        private System.Windows.Forms.TextBox txbxCity;
        private System.Windows.Forms.TextBox txbxState;
        private System.Windows.Forms.TextBox txbxZip;
        private System.Windows.Forms.TextBox txbxPhone;
        private System.Windows.Forms.TextBox txbxEmail;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Button btnTestFill;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Label lblCell;
        private System.Windows.Forms.Label lblInsta;
        private System.Windows.Forms.TextBox txbxCell;
        private System.Windows.Forms.TextBox txbxInsta;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblPersonV2_ID;
        private System.Windows.Forms.Label label1;
    }
}

