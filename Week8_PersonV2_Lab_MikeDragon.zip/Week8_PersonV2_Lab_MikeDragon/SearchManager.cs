﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Week6_Lab6_MikeDragon
{
    public partial class SearchManager : Form
    {
        public SearchManager()
        {
            InitializeComponent();
        }

        //Closes only SearchManager()
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //Obtains the Search criteria (or all data if nothing else is selected) and displays in DataGridView
        private void btnSearch_Click(object sender, EventArgs e)
        {
            PersonV2 temp = new PersonV2();

            //Get data
            DataSet DSet = temp.SearchPersonV2(txbxFirstName.Text, txbxLastName.Text);

            //Display DataSet
            dgvResults.DataSource = DSet;
            dgvResults.DataMember = DSet.Tables["PersonV2_Temp"].ToString();
        }

        private void dgvResults_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            string strPersonV2_ID = (dgvResults.Rows[e.RowIndex].Cells[0].Value.ToString());

            int intPersonV2_ID = Convert.ToInt32(strPersonV2_ID);

            Form1 Edit = new Form1(intPersonV2_ID);

            //I want this specific instance to remain the focus, unlike the other windows (Dialog)
            Edit.ShowDialog();
        }
    }
}
