﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace Week6_Lab6_MikeDragon
{
    //Inheriting data from the parent class: Person()
    class PersonV2: Person
    {
        private string cell;
        private string insta;

        //Start of public Get/Sets

        //Needs validation: (Length - 12)
        public string Cell
        {
            get
            {
                return cell;
            }

            set
            {
                if (ValidationLibrary.MinAmount(value, 12) == true)
                {
                    cell = value;
                }

                else
                {
                    Feedback = ($"ERROR: The entry for [Cell Phone] was not properly formatted. Use only 10 numbers and (-). (Ex: 860-208-0101)");
                }
            }
        }

        //Needs validation: Checks for 'instagram.com/' | Error if not contained
        public string Insta
        {
            get
            {
                return insta;
            }

            set
            {
                if (ValidationLibrary.InstaCheck(value) == true)
                {
                    insta = value;
                }

                else
                {
                    Feedback = ($"ERROR: The entry for [Instagram] was not properly formatted. (Ex: instagram.com/...)");
                }
            }
        }

        //Connects to the SQL Server
        public string AddARecord()
        {
            string result = "";

            SqlConnection Connect = new SqlConnection();

            Connect.ConnectionString = @"Server=sql.neit.edu\studentsqlserver,4500;Database=SE245_MDragon;User Id=SE245_MDragon;Password=000859945;";

            //Adding of the Record:
            string strSQL = "INSERT INTO PersonV2 (FirstName, MiddleName, LastName, Street1, Street2, City, State, Zip, Phone, Cell, Email, Insta) VALUES (@FirstName, @MiddleName, @LastName, @Street1, @Street2, @City, @State, @Zip, @Phone, @Cell, @Email, @Insta)";

            SqlCommand comm = new SqlCommand();
            comm.CommandText = strSQL;
            comm.Connection = Connect;

            //Entering the data from the form fields
            comm.Parameters.AddWithValue("@FirstName", FirstName);
            comm.Parameters.AddWithValue("@MiddleName", MiddleName);
            comm.Parameters.AddWithValue("@LastName", LastName);
            comm.Parameters.AddWithValue("@Street1", Street1);
            comm.Parameters.AddWithValue("@Street2", Street2);
            comm.Parameters.AddWithValue("@City", City);
            comm.Parameters.AddWithValue("@State", State);
            comm.Parameters.AddWithValue("@Zip", Zip);
            comm.Parameters.AddWithValue("@Phone", Phone);
            comm.Parameters.AddWithValue("@Cell", Cell);
            comm.Parameters.AddWithValue("@Email", Email);
            comm.Parameters.AddWithValue("@Insta", Insta);

            try
            {
                Connect.Open();
                int RecordsAdded = comm.ExecuteNonQuery();
                result = $"Added {RecordsAdded} record(s) successfully.";
                Connect.Close();
            }

            catch (Exception error)
            {
                result = "ERROR: " + error.Message;
            }

            finally
            {

            }

            return result;
        }

        //Searching PersonV2() function
        public DataSet SearchPersonV2(string FirstName, string LastName)
        {
            DataSet DSet = new DataSet();

            SqlCommand comm = new SqlCommand();

            string strSQL = "SELECT PersonV2_ID, FirstName, LastName FROM PersonV2 WHERE 0=0";

            //Checks for Person's First/Last Name -> Adds to search
            if (FirstName.Length > 0)
            {
                strSQL += " AND FirstName LIKE @FirstName";
                comm.Parameters.AddWithValue("@FirstName", "%" + FirstName + "%");
            }

            if (LastName.Length > 0)
            {
                strSQL += " AND LastName LIKE @LastName";
                comm.Parameters.AddWithValue("@LastName", "%" + LastName + "%");
            }

            //DataBase Tools
            SqlConnection Connect = new SqlConnection();
            Connect.ConnectionString = @GetConnected();

            comm.Connection = Connect;
            comm.CommandText = strSQL;

            //DataAdapter
            SqlDataAdapter DAdapt = new SqlDataAdapter();
            DAdapt.SelectCommand = comm;    //Commander uses DataAdapter to communicate w/ DataSets

            //Obtaining the Data, itself
            Connect.Open();
            DAdapt.Fill(DSet, "PersonV2_Temp");
            Connect.Close();

            //Return Data
            return DSet;
        }

        //Using PersonV2_ID, find one person's data > Store in a DataReader to return
        public SqlDataReader FindPerson(int intPersonV2_ID)
        {
            //DataBase Tools
            SqlConnection Connect = new SqlConnection();
            SqlCommand comm = new SqlCommand();

            Connect.ConnectionString = @GetConnected();

            string strSQL = "SELECT * FROM PersonV2 WHERE PersonV2_ID = @PersonV2_ID;";

            comm.Connection = Connect;
            comm.CommandText = strSQL;
            comm.Parameters.AddWithValue("@PersonV2_ID", intPersonV2_ID);

            //Open connection
            Connect.Open();

            //Return DataReader
            return comm.ExecuteReader();
        }

        //SQL Server Login Function
        private string GetConnected()
        {
            return @"Server=sql.neit.edu\studentsqlserver,4500;Database=SE245_MDragon;User Id=SE245_MDragon;Password=000859945;";
        }

        //Constructor for PersonV2() class
        public PersonV2(): base()
        {
            cell = "";
            insta = "";
        }
    }
}
