﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Week6_Lab6_MikeDragon
{
    public partial class GrayPages : Form
    {
        public GrayPages()
        {
            InitializeComponent();
        }

        //Loads up Form1() to enter a new Person
        private void btnAddPerson_Click(object sender, EventArgs e)
        {
            Form1 temp = new Form1();
            temp.Show();
        }

        //Loads up SearchManager() to search/view people's data
        private void btnSearch_Click(object sender, EventArgs e)
        {
            SearchManager temp = new SearchManager();
            temp.Show();
        }

        //Closes the Main Program
        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
