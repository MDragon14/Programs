﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Week6_Lab6_MikeDragon
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Gathers PersonV2 data based on PersonV2_ID > displays in Form1() 
        public Form1(int intPersonV2_ID)
        {
            InitializeComponent();

            PersonV2 temp = new PersonV2();

            SqlDataReader DR = temp.FindPerson(intPersonV2_ID);

            while (DR.Read())
            {
                txbxFirstName.Text = DR["FirstName"].ToString();
                txbxMiddleName.Text = DR["MiddleName"].ToString();
                txbxLastName.Text = DR["LastName"].ToString();
                txbxStreet1.Text = DR["Street1"].ToString();
                txbxStreet2.Text = DR["Street2"].ToString();
                txbxCity.Text = DR["City"].ToString();
                txbxState.Text = DR["State"].ToString();
                txbxZip.Text = DR["Zip"].ToString();
                txbxPhone.Text = DR["Phone"].ToString();
                txbxEmail.Text = DR["Email"].ToString();
                txbxCell.Text = DR["Cell"].ToString();
                txbxInsta.Text = DR["Insta"].ToString();

                lblPersonV2_ID.Text = DR["PersonV2_ID"].ToString();
            }
        }

        //TESTING ONLY: Auto-fills the form
        private void btnTestFill_Click(object sender, EventArgs e)
        {
            txbxFirstName.Text = "Michael";
            txbxMiddleName.Text = "Anthony";
            txbxLastName.Text = "Dragon";
            txbxStreet1.Text = "114 Breakneck Hill Road";
            txbxStreet2.Text = "N/A";
            txbxCity.Text = "Dayville";
            txbxState.Text = "CT";
            txbxZip.Text = "06241";
            txbxPhone.Text = "860-208-9393";
            txbxEmail.Text = "madragon@email.neit.edu";
            txbxCell.Text = "860-617-6400";
            txbxInsta.Text = "instagram.com/MavereX";
        }

        //TESTING ONLY: Clears the form
        private void btnClear_Click(object sender, EventArgs e)
        {
            txbxFirstName.Text = "";
            txbxMiddleName.Text = "";
            txbxLastName.Text = "";
            txbxStreet1.Text = "";
            txbxStreet2.Text = "";
            txbxCity.Text = "";
            txbxState.Text = "";
            txbxZip.Text = "";
            txbxPhone.Text = "";
            txbxEmail.Text = "";
            txbxCell.Text = "";
            txbxInsta.Text = "";

            lblFeedback.Text = "...";
        }

        //Submits the data when there are no more errors!
        private void btnSubmit_Click(object sender, EventArgs e)
        {
            PersonV2 temp = new PersonV2();

            temp.FirstName = txbxFirstName.Text;
            temp.MiddleName = txbxMiddleName.Text;
            temp.LastName = txbxLastName.Text;
            temp.Street1 = txbxStreet1.Text;
            temp.Street2 = txbxStreet2.Text;
            temp.City = txbxCity.Text;
            temp.State = txbxState.Text;
            temp.Zip = txbxZip.Text;
            temp.Phone = txbxPhone.Text;
            temp.Email = txbxEmail.Text;
            temp.Cell = txbxCell.Text;
            temp.Insta = txbxInsta.Text;

            //Feedback Output
            if (temp.Feedback.Contains("ERROR:"))
            {
                lblFeedback.Text = temp.Feedback;
            }

            else
            {
                lblFeedback.Text = temp.AddARecord();
            }
        }

        //Closes only Form1()
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
